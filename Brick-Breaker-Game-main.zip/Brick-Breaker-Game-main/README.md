# Brick-Breaker-Game
A simple Brick Breaker Game where the ball break the bricks while being reflected by the slider.
Tech-Stack: Java Swing, Java Awt
